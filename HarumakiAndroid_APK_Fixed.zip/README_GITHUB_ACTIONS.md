# Harumaki Android APK build

## Important
The contents of this folder are the Android project root.
Do not upload the outer `HarumakiAndroid_APK_Fixed` folder itself as a nested folder in GitHub.
The repository root must contain:

- `app/`
- `.github/workflows/build-apk.yml`
- `build.gradle`
- `settings.gradle`

## APK output
Run `Build Harumaki APK` in GitHub Actions. The workflow searches for every generated `.apk` file, copies it into `artifact-apk/`, verifies that at least one APK exists, and then uploads it as the `Harumaki-debug-apk` artifact.

If no APK is generated, the workflow fails instead of showing a false success.
